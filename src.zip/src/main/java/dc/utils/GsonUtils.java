package dc.utils;

import com.google.gson.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.lang.reflect.Type;
import java.util.Base64;
import java.io.*;

public class GsonUtils {
    private static final Gson gson = new GsonBuilder()
            .registerTypeAdapter(ItemStack.class, new ItemStackAdapter())
            .setPrettyPrinting()
            .create();

    public static Gson getGson() {
        return gson;
    }

    // Adaptador para serializar/deserializar ItemStack con base64
    public static class ItemStackAdapter implements JsonSerializer<ItemStack>, JsonDeserializer<ItemStack> {
        @Override
        public JsonElement serialize(ItemStack item, Type type, JsonSerializationContext context) {
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                 ObjectOutputStream oos = new BukkitObjectOutputStream(baos)) {
                oos.writeObject(item);
                return new JsonPrimitive(Base64.getEncoder().encodeToString(baos.toByteArray()));
            } catch (IOException e) {
                e.printStackTrace();
                return JsonNull.INSTANCE;
            }
        }

        @Override
        public ItemStack deserialize(JsonElement json, Type type, JsonDeserializationContext context) throws JsonParseException {
            byte[] data = Base64.getDecoder().decode(json.getAsString());
            try (ByteArrayInputStream bais = new ByteArrayInputStream(data);
                 ObjectInputStream ois = new BukkitObjectInputStream(bais)) {
                return (ItemStack) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}
