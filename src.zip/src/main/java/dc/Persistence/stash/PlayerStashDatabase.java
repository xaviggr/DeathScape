package dc.Persistence.stash;

import com.google.gson.reflect.TypeToken;
import dc.utils.GsonUtils;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.*;

public class PlayerStashDatabase {
    private static final File file = new File("plugins/DeathScape/PlayerStashData.json");
    private static final Type type = new TypeToken<Map<String, List<ItemStack>>>() {}.getType();

    private static Map<String, List<ItemStack>> data = new HashMap<>();

    public static void load() {
        if (!file.exists()) return;
        try (FileReader reader = new FileReader(file)) {
            data = GsonUtils.getGson().fromJson(reader, type);
        } catch (Exception e) {
            Bukkit.getLogger().warning("Error loading PlayerStashData: " + e.getMessage());
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(file)) {
            GsonUtils.getGson().toJson(data, writer);
        } catch (Exception e) {
            Bukkit.getLogger().warning("Error saving PlayerStashData: " + e.getMessage());
        }
    }

    public static List<ItemStack> getStash(String playerName) {
        return data.getOrDefault(playerName, new ArrayList<>());
    }

    public static void setStash(String playerName, List<ItemStack> stash) {
        data.put(playerName, stash);
        save();
    }
}